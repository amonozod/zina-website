// Shared helpers for the embedded AI practice widgets on Writing & Speaking pages.

function formatTime(s) {
  const m = Math.floor(s / 60), sec = s % 60;
  return String(m).padStart(2, "0") + ":" + String(sec).padStart(2, "0");
}

async function callClaude(system, userText) {
  const response = await fetch("/.netlify/functions/grade", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ system, userText })
  });
  if (!response.ok) throw new Error("API request failed (" + response.status + ")");
  const data = await response.json();
  const text = (data.content || []).map(b => b.text || "").join("\n");
  const clean = text.replace(/```json|```/g, "").trim();
  return JSON.parse(clean);
}

function renderExamResult(container, json) {
  const criteriaHtml = json.criteria.map(c => `
    <div class="criteria-item">
      <span class="cname">${c.name}</span>
      <span class="cband">${c.band.toFixed(1)}</span>
      <span class="ccomment">${c.comment}</span>
    </div>`).join("");

  const strengths = (json.strengths || []).map(s => `<li>${s}</li>`).join("");
  const improvements = (json.improvements || []).map(s => `<li>${s}</li>`).join("");

  container.innerHTML = `
    <div class="result-card">
      <div class="result-head">
        <div>
          <div class="phase-label" style="color:rgba(255,255,255,0.75);">Overall band score</div>
          <div class="band">${json.overallBand.toFixed(1)}</div>
        </div>
      </div>
      <div class="result-body">
        <div class="criteria-list">${criteriaHtml}</div>
        <div class="fb-cols">
          <div><h4>What worked well</h4><ul>${strengths}</ul></div>
          <div><h4>What to improve</h4><ul>${improvements}</ul></div>
        </div>
      </div>
    </div>`;
}

function setupSpeechRecognition(onResult) {
  const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognitionAPI) return null;
  const recognition = new SpeechRecognitionAPI();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = "en-US";
  recognition.onresult = (e) => {
    let finalText = "";
    for (let i = 0; i < e.results.length; i++) finalText += e.results[i][0].transcript + " ";
    onResult(finalText.trim());
  };
  return recognition;
}
